#!/usr/bin/env bash
# Host controller: one new, UUID-verified FEMU instance per run.
# Same computer: ./03_host_loop.sh "single lan" 0.70, review, then 0.93.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
set -a; . "$HERE/config.env"; set +a
POLICIES="${1:-single lan}"
UTILS="${2:-0.70}"
REP="${REP:-1}"
SUFFIX=""; [[ "$REP" != 1 ]] && SUFFIX="_r$REP"
FEMU_START_CMD="${FEMU_START_CMD:-$(printf '%q' "$HERE/femu/start_femu.sh")}"
for v in FEMU_START_CMD FEMU_BIN FEMU_GUEST_IMAGE GUEST_SSH GUEST_DIR; do
  [[ -n "${!v}" ]] || { echo "config.env: $v is empty"; exit 1; }
done
[[ "$REP" =~ ^[1-9][0-9]*$ ]] || { echo "Invalid REP"; exit 1; }
for POL in $POLICIES; do
  [[ "$POL" == single || "$POL" == lan || "$POL" == single6 ]] || { echo "Invalid policy: $POL"; exit 1; }
done
for U in $UTILS; do [[ "$U" =~ ^0\.[0-9]+$ ]] || { echo "Invalid utilization: $U"; exit 1; }; done
LOGDIR="$HOST_RESULTS/host_logs"
mkdir -p "$LOGDIR" "$(dirname "$FEMU_QMP_SOCK")"
# Prevent two campaigns sharing the same QMP/backend and SSH port.
exec 9>"${FEMU_QMP_SOCK}.campaign.lock"
flock -n 9 || { echo "Another campaign owns $FEMU_QMP_SOCK"; exit 1; }
# shellcheck disable=SC2086
gssh() { ssh -o BatchMode=yes -o ConnectTimeout=5 -o ServerAliveInterval=30 \
  -o StrictHostKeyChecking=accept-new $GUEST_SSH_OPTS "$GUEST_SSH" "$@"; }
GUEST_ENV="cd $(printf '%q' "$GUEST_DIR") && set -a && . ./config.env && set +a"
if [[ "${FORCE:-0}" != 1 ]]; then
  echo "run마다 FEMU 재시작, 전용 장치 데이터 삭제. 계속: yes"
  read -r ans; [[ "$ans" == yes ]] || exit 1
fi
FPID=""; VM_VERIFIED=0
signal_femu() {
  [[ -n "$FPID" ]] || return 0
  kill "-$1" -- "-$FPID" 2>/dev/null || kill "-$1" "$FPID" 2>/dev/null || true
  if [[ "$FEMU_SUDO" == 1 ]]; then sudo -n kill "-$1" -- "-$FPID" 2>/dev/null || true; fi
}
stop_femu() {
  [[ -n "$FPID" ]] || return 0
  # An unverified SSH endpoint may belong to somebody else. Never power it off.
  if (( VM_VERIFIED )); then gssh "sudo -n poweroff" >/dev/null 2>&1 || true
  else signal_femu TERM
  fi
  local t=0
  while kill -0 "$FPID" 2>/dev/null && (( t < SHUTDOWN_TIMEOUT_SEC )); do sleep 2; t=$((t+2)); done
  if kill -0 "$FPID" 2>/dev/null; then
    signal_femu TERM; sleep 2; signal_femu KILL
    t=0
    while kill -0 "$FPID" 2>/dev/null && ((t < 30)); do sleep 1; t=$((t+1)); done
    if kill -0 "$FPID" 2>/dev/null; then echo "Cannot stop owned FEMU PID $FPID" >&2; return 1; fi
  fi
  wait "$FPID" 2>/dev/null || true
  FPID=""; VM_VERIFIED=0
}
cleanup_host() {
  local rc=$?
  trap - EXIT
  stop_femu || rc=1
  exit "$rc"
}
trap cleanup_host EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

for U in $UTILS; do
  for POL in $POLICIES; do
    TAG="${POL}_u${U}${SUFFIX}"
    RUN_ID=$(python3 -c 'import uuid; print(uuid.uuid4())')
    HOST_MANIFEST="$LOGDIR/host_${TAG}_${RUN_ID}.json"
    python3 "$HERE/runcheck.py" host "$HOST_MANIFEST" "$RUN_ID"
    if [[ -f "$HOST_RESULTS/$TAG/done" ]]; then
      # Reuse only a complete run with this source/config/host/QEMU provenance.
      python3 - "$HERE" "$HOST_RESULTS/$TAG" "$HOST_MANIFEST" <<'PY'
import sys
sys.path.insert(0, sys.argv[1])
import runcheck
run, current = sys.argv[2:]
m = runcheck.load(run + '/manifest.json')
h = runcheck.load(current)
if runcheck.validate(run)['status'] != 'VALID':
    raise SystemExit('Existing done run fails validation; archive it before retrying')
for key in ('hostname', 'qemu_sha256', 'source', 'config'):
    if m['host'][key] != h[key]:
        raise SystemExit('Existing done run differs: ' + key + '; use a new results directory')
PY
      echo "[건너뜀] $TAG 완료·설정 검증 통과"
      continue
    fi
    if [[ -e "$HOST_RESULTS/$TAG" ]]; then
      mkdir -p "$HOST_RESULTS/attempts"
      mv "$HOST_RESULTS/$TAG" "$HOST_RESULTS/attempts/${TAG}_${RUN_ID}"
    fi
    [[ ! -e "$FEMU_QMP_SOCK" ]] || { echo "QMP socket already exists: $FEMU_QMP_SOCK"; exit 1; }
    python3 - "$FEMU_SSH_PORT" <<'PY'
import socket, sys
with socket.socket() as s:
    try: s.bind(('127.0.0.1', int(sys.argv[1])))
    except OSError as e: raise SystemExit('SSH forwarding port is occupied: ' + str(e))
PY
    FEMU_LOG="$LOGDIR/femu_${TAG}_${RUN_ID}.log"
    # A unique actual log is preserved for every attempt. Canonical name is only a link.
    if [[ -e "$LOGDIR/femu_$TAG.log" && ! -L "$LOGDIR/femu_$TAG.log" ]]; then
      mkdir -p "$LOGDIR/attempts"
      mv "$LOGDIR/femu_$TAG.log" "$LOGDIR/attempts/femu_${TAG}_${RUN_ID}.previous.log"
    fi
    ln -sfn "$(basename "$FEMU_LOG")" "$LOGDIR/femu_$TAG.log"
    PILOT_POLICY="$POL" FEMU_RUN_ID="$RUN_ID" setsid bash -c "$FEMU_START_CMD" > "$FEMU_LOG" 2>&1 < /dev/null &
    FPID=$!; VM_VERIFIED=0
    echo "[host] $TAG FEMU pid=$FPID uuid=$RUN_ID"
    t=0
    while :; do
      kill -0 "$FPID" 2>/dev/null || { echo "New FEMU exited: $FEMU_LOG"; exit 1; }
      if uuid=$(gssh 'sudo -n cat /sys/class/dmi/id/product_uuid' 2>/dev/null); then
        kill -0 "$FPID" 2>/dev/null || { echo "New FEMU exited during SSH probe"; exit 1; }
        [[ "${uuid,,}" == "$RUN_ID" ]] || { echo "SSH guest UUID mismatch; refusing workload"; exit 1; }
        VM_VERIFIED=1
        break
      fi
      (( t < BOOT_TIMEOUT_SEC )) || { echo "Guest boot timeout"; exit 1; }
      sleep 5; t=$((t+5))
    done
    gssh 'cat > /tmp/fdp-pilot-host.json' < "$HOST_MANIFEST"
    if [[ -n "$GUEST_PREP_CMD" ]]; then
      gssh "$GUEST_PREP_CMD" > "$LOGDIR/prep_${TAG}_${RUN_ID}.log" 2>&1
    fi
    # Guest archives any partial result itself; no raw result folder is deleted here.
    REMOTE_LOG="fdp_run_${TAG}_${RUN_ID}.log"
    REMOTE_PID="fdp_run_${TAG}_${RUN_ID}.pid"
    gssh "$GUEST_ENV && { nohup sudo -n -E env WORK=\"\$WORK\" RESULTS=\"\$RESULTS\" FORCE=1 FRESH_FEMU=1 NO_SUMMARY=1 REP=$REP FEMU_RUN_ID=$RUN_ID OVERWRITE_MULT=$OVERWRITE_MULT ./02_femu_run.sh '$POL' '$U' > \"\$HOME/$REMOTE_LOG\" 2>&1 < /dev/null & echo \$! > \"\$HOME/$REMOTE_PID\"; } && echo started"
    fails=0
    while :; do
      sleep "$POLL_SEC"
      kill -0 "$FPID" 2>/dev/null || { echo "FEMU exited during workload: $FEMU_LOG"; exit 1; }
      rc=0; gssh "ps -p \"\$(cat \"\$HOME/$REMOTE_PID\")\" >/dev/null" || rc=$?
      if ((rc == 0)); then fails=0; continue; fi
      if ((rc == 255)); then
        fails=$((fails+1)); echo "[host] Guest connection failed ($fails/10)"
        ((fails < 10)) || exit 1
        continue
      fi
      break
    done
    gssh "cat \"\$HOME/$REMOTE_LOG\"" > "$LOGDIR/run_${TAG}_${RUN_ID}.log"
    gssh "$GUEST_ENV && cd \"\$RESULTS\" && tar cf - '$TAG'" | tar xf - -C "$HOST_RESULTS"
    stop_femu
    [[ -f "$HOST_RESULTS/$TAG/done" ]] || { echo "[host] $TAG 미완료/검증 실패; 원본 보존 후 중단"; exit 1; }
    echo "[host] $TAG 완료"
  done
done
python3 "$HERE/pilot.py" summary "$HOST_RESULTS" | tee "$HOST_RESULTS/summary.txt"
