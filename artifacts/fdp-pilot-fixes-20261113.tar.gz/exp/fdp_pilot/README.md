# FDP 파일럿: 높은 사용률에서 FDP의 WAF 이득이 줄어드는가

2026-11-13 수정. **70%와 93%, 모든 정책을 같은 컴퓨터에서 실행한다.** 각 run은 새 FEMU에서 시작한다. 결과는 1회 파일럿의 방향 확인용이며, 원인이나 통계적 우월성을 확정하는 실험은 아니다.

## 고정 조건

| 항목 | 값 |
|---|---|
| 정책 | single: 모두 PID0 / lan: WAL0, L0–L3 1, L4 2, L5+ 3, MANIFEST4 / 선택 대조 single6 |
| 순서 | **70% single → lan → gain≥10%이면 93% single → lan → 시간 남으면 93% single6** |
| 제외 | lan3, 70% single6, REP=2, zipfian 등 추가 workload는 후속연구. 11/26 전 새 정책·설정 추가 없음 |
| SSD | 사용자24GiB(192RU), 물리211RU, RU128MiB, 실제OP9.8958% |
| FDP | 모든 RUH II. single2 / lan6 / single6 6. 마지막RUH는 GC용으로 host에 미노출 |
| GC | greedy, trigger90/99: freeRU≤21/2일 때 GC 시도. lazyvalid5%·block remapping 없음 |
| workload | RocksDB7.2.2+고정Lan패치, TorFS고정commit+PID패치. load filluniquerandom 1thread → overwrite 균등random 4threads |
| 데이터 | key16B/value1024B, seed1, overwrite2배. L1/SST/memtable=2.5/0.5/1MiB, compression none, background4 |
| 측정 구간 | **overwrite 실행 시간**의 전체·가운데1/3·마지막1/3. timestamp 경계를 보간하며 샘플 개수로 자르지 않음 |
| 공간 | `(1.0134×논리+3.047GiB)×1.02+TorFS메타2GiB = 목표×24GiB` |
| 초기화 | run마다 새 FEMU process·UUID. 게스트 OS 디스크는 유지, SSD backend 파일은 새로 생성 |

`config.env`가 공통 설정의 기준이다. 호스트별 바이너리·이미지·SSH 경로는 다를 수 있지만 실험 설정은 호스트/게스트에서 일치해야 한다. 새 컴퓨터의 RAM이 많아도 guest memory/CPU를 run마다 바꾸지 않는다.

## 판정

`gain = 1−WAF_lan/WAF_single`은 **host byte당 Media인 WAF의 감소율**이다. 총 Media byte의 감소율이 아니다. host 쓰기량이 다르면 두 비율은 다르므로 표의 host/media 실제 byte도 함께 보고한다.

| 조건 | 처리 |
|---|---|
| 유효한70% pair가 없거나 gain<10% | 보류. 93% 실행 생략 |
| gain93/gain70<0.4 | 높은 사용률에서 WAF 이득 감소 관찰 |
| 0.4~0.6 | 경계로 보고. 이번 캠페인에서 추가 반복하지 않음 |
| >0.6 | 이 파일럿에서 뚜렷한 감소를 확인하지 못함. 새 workload 자동 추가 안 함 |

완료·옵션·PID·계측·작업량·실제 사용률·L6 검사를 통과해야 gain에 사용한다. 가운데/마지막 시간1/3 WAF 차이가5%를 넘으면 과도 상태로 표시하고 collapse 결론은 보류한다. overwrite2배가 안정상태를 보장하지는 않는다.

실제 최고 사용률의 허용차는 `UTIL_TOL=0.03`(목표±3 percentage points)로 사전 고정한다. 이는 파일럿 공간 보정이 크게 어긋난 결과를 자동 판정에서 빼기 위한 운영 기준이며 새로운 sweep 변수는 아니다. 범위를 벗어나면 원인을 확인하고 보류한다. 결과를 보고 유리하게 허용차·종료량을 바꾸지 않는다.

single6를 실행하면 같은 컴퓨터의93% pair와 비교한다. single↔single6는 동일 single 배치에서 RUH 수를 늘리는 영향, single6↔lan은 같은 RUH 수에서 배치의 영향을 비교한다. single6가 없으면 열린 RU의 비용은 원인 후보로만 쓴다.

## 실행 순서

서버 환경·권한 준비는 [SETUP_NOTES.md](SETUP_NOTES.md)를 따른다. 이 문서의 명령은 FEMU/게스트/빌드가 준비된 뒤 **호스트의 `exp/fdp_pilot`에서** 실행한다. 설치되지 않은 서버 홈에서 바로 동작하는 명령이 아니다.

1. 이 수정본의 같은 소스 버전을 호스트와 게스트에 배치한다. 기존 오래된 저장소·이미지·결과를 덮어쓰지 않는다.
2. 호스트에서 FEMU 빌드. 게스트에서 xNVMe 설치 후 `JOBS=8 ./00_build.sh femu`로 db_bench와 `.build.json`을 함께 만든다.
3. 호스트 `config.env`의 FEMU_BIN, FEMU_GUEST_IMAGE, GUEST_SSH, GUEST_SSH_OPTS, GUEST_DIR 및 실행 권한 방식을 채운다.
4. 정책별 장치·계측·deallocate 기능 확인을 끝내고 작은 시험을 별도 결과 폴더에서 실행한다.

```bash
HOST_RESULTS=~/fdp_smoke_gc90 FORCE=1 OVERWRITE_MULT=0.2 \
  ./03_host_loop.sh lan 0.35
```

작은 시험은 낮은 사용률·짧은 overwrite로 pipeline을 확인한다. 부족한 샘플이나 실제 사용률 오차 때문에 판정 보류가 나올 수 있으며, 이것을 본 실험의 통과 결과로 대체하지 않는다.

5. 같은 호스트에서70% pair를 실행한다.

```bash
HOST_RESULTS=~/fdp_pilot_results_gc90 ./03_host_loop.sh "single lan" 0.70
```

6. 유효한 pair의 gain≥10%인 것을 확인한 뒤 **같은 결과 루트/같은 호스트**에서93% pair를 실행한다. 두 사용률을 한 명령에 넣어 관문을 건너뛰지 않는다.

```bash
HOST_RESULTS=~/fdp_pilot_results_gc90 ./03_host_loop.sh "single lan" 0.93
```

7. 시간이 남으면93% single6만 추가한다.

```bash
HOST_RESULTS=~/fdp_pilot_results_gc90 ./03_host_loop.sh single6 0.93
```

중간 실패 시 다음 정책을 계속 돌리지 않는다. 실패 결과와 로그는 attempt별 보존한다. 재시도는 원인을 해결한 뒤 새 attempt에서 수행한다. 이미 완료된 run도 manifest가 현재 설정/소스와 맞는지 확인하며, 단순히 같은 폴더 이름이라는 이유로 재사용하지 않는다.

## 빌드 고정과 기록

- RocksDB tag v7.2.2 및 full commit `f2f26b1559b77f56f3074c5cb7d93112b2dd3f9f`.
- TorFS full commit `0a6e399aa3df0b5cd5bbe9d9ccee09d853f3a95a`와 `patches/torfs_force_pid.patch`.
- Lan patch 저장소 full commit `752f9c05112891595f5ad008b57a39b8e1880f66`.
- 기존 소스 폴더에서도 base commit과 적용 패치를 검증한다. Lan 저장소의 local 변경은 자동 checkout으로 덮어쓰지 않는다.
- `db_bench_torfs.build.json`에 실제 binary SHA256, 소스 commit/diff, Lan patch SHA256, xNVMe version을 보존한다. binary만 따로 복사하지 않는다.
- 각 run manifest에 코드·공통 설정·호스트·QEMU hash·guest build·kernel/nvme version·UUID를 기록한다. 게스트 실행 전에 호스트/게스트 설정과 소스를 대조한다.
- 중간 clone/patch/build 실패로 폴더만 생겼다면 완료 소스로 취급하지 않는다. 현재 폴더를 보존하고 원인을 확인하거나 새 `WORK` 경로에서 빌드한다.

```bash
WORK="$HOME/fdp_pilot_work_retry" JOBS=8 ./00_build.sh femu
```

실험 중 commit·패치·라이브러리나 LSM/SSD 설정을 바꾸지 않는다. 수정이 필요하면 기존 결과와 별도 캠페인으로 기록한다.

## 완료와 계측 검증

- run 시작: 새 QEMU의 생존·UUID 확인, 장치 fresh counter/valid 상태 확인, 정책별 devcheck.
- 실행 중: counter/usage 조회 실패와 sampler 종료를 무시하지 않고 workload를 중단한다.
- 종료: load/overwrite rc0, 계획한 application write count 완료, 옵션 통과, sampler 성공·계측 범위/샘플 공백·counter 단조성, invalidPID0, L6 없음, 실제 사용률을 확인한다.
- 결과의 `done`은 완료 검증 뒤 생성한다. summary는 미완료나 검증 실패 run을 진단으로만 표시한다. `validation.json`과 경고를 함께 본다.
- 오래된 결과처럼 manifest·완료 증거가 없는 자료는 참고/진단용이며 새 자동 판정에 섞지 않는다.
- host_logs도 원본 결과의 일부다. GC 로그가 없으면 run 당시 manifest 설정을 쓰며, 둘 다 없으면 unknown으로 둔다. 현재 config를 과거 결과에 대입하지 않는다.

장치에서 읽는 주요 값은 FDP22h의 host/media byte, 이 브랜치 C1h의 valid/capacity/invalidPID/RUH별 host·media·live다. C1h는 현재 물리 소유 기준이고, GC media는 victim/sourceRUH에 귀속된다. **RUH별 media는 원래 SST 레벨별 GC 비용이 아니다.**

## 해석 범위

- WARP에서 참고한 것은 trigger90/99다. 이 모델의 BG1/8 규칙과 valid-page copy는 WARP lazy GC·block remapping과 다르다. WAF 절댓값을 WARP/실장치와 직접 동등 비교하지 않는다.
- BG21RU는 GC 시도 기준이지 영구 예약 공간이 아니다. `전체−GC기준−열린RU−valid`는 실제 freeRU가 아니며 openRU의 valid를 중복 차감할 수 있다. 이 값으로 열린 RU 손실을 확정하지 않는다.
- GC RUH의 live 비중이 높다는 것은 데이터가 GC를 거쳐 그 RUH에 있다는 뜻이다. 섞임 때문에 몇 byte의 GC가 늘었는지는 이 로그만으로 분해할 수 없다.
- 같은 컴퓨터라도 RocksDB의 병렬 compaction과 scheduling에는 변동이 있다. seed1의 1회 결과로 통계적 우월성이나 실장치 일반성을 주장하지 않는다.
- 예전75/95, overwrite1배 결과는 현재90/99, overwrite2배 결과와 직접 인과 비교하지 않는다. 과거 gain−12.2%는 그때의 샘플 index 구간으로 계산한 **WAF 비율**이며 총 Media 증가율이 아니다.
- load/overwrite 뒤 wait·LOG 저장 구간은 주 WAF에서 분리한다. 측정은 비동기 샘플러이므로 경계 오차가 있으며, 허용 공백/coverage 검사를 함께 적용한다.
- NOFSYNC PC 보정값은 예비 공간 식이다. FEMU 실사용률로 재확인한다. gc 발생·deallocate 기능은 초기 smoke/qtest로 따로 검증한다.

## 결과 보관

결과 폴더 전체와 `host_logs`, manifest, `.build.json`, `validation.json`, 원본 CSV·phase_events·stdout/stderr·LOG.gz를 함께 보존한다. 기본 게스트8GiB·4vCPU 및 파일 backend를 유지한다. LOG 원본은 매우 커서 guest/host 디스크 여유를 확인한다.

원본 결과는 덮어쓰지 않는다. GC75/95 예비 결과는 별도 폴더에 그대로 남기고 현재 캠페인에는 새 결과 루트를 사용한다. 최종 분석은 반복적인 에이전트 조회 없이 스크립트 완료 후 수행할 수 있다.
